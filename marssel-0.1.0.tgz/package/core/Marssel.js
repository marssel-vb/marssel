import { FontManager } from "../managers/FontManager.js";
import { IconManager } from "../managers/IconManager.js";
import { StyleManager } from "../managers/StyleManager.js";
import { DomManager } from "../managers/DomManager.js";
import { ModalManager } from "../managers/ModalManager.js";

import { ScrollspyManager } from "../managers/ScrollspyManager.js";
import { ToastManager } from "../managers/ToastManager.js";
import { TooltipManager } from "../managers/TooltipManager.js";

import { HeaderManager } from "../managers/HeaderManager.js";

import { CarouselManager } from "../managers/CarouselManager.js";

import { DropdownManager } from "../managers/DropdownManager.js";

import { OffcanvasManager } from "../managers/OffcanvasManager.js";

import { PopoverManager } from "../managers/PopoverManager.js";

import {
    properties,
    breakpoints,
    containerMaxWidths,
    CLASS_REGEX,
    COLOR_REGEX,
} from "../utils/constants.js";

export class Marssel {
    constructor(userOptions = {}) {
        console.log("Début du constructeur Marssel");

        // Définir explicitement les options comme propriété de l'instance
        this.config = {
            lazyload:
                userOptions && userOptions.lazyload
                    ? userOptions.lazyload
                    : false,
        };

        console.log("Options configurées:", this.config);

        // Initialiser les managers un par un avec des logs
        console.log("Initialisation FontManager");
        this.fontManager = new FontManager(this);

        console.log("Initialisation IconManager");
        this.iconManager = new IconManager(this);

        console.log("Initialisation StyleManager");
        // Passer l'objet de configuration au StyleManager
        this.styleManager = new StyleManager(this, this.config);

        console.log("Initialisation DomManager");
        this.domManager = new DomManager(this);

        console.log("Initialisation ModalManager");
        this.modalManager = new ModalManager(this);

        this.scrollspyManager = new ScrollspyManager(this);
        this.toastManager = new ToastManager(this);
        this.tooltipManager = new TooltipManager(this);
        this.headerManager = new HeaderManager(this);

        // Initialiser les autres managers un par un
        console.log("Initialisation CarouselManager");
        this.carouselManager = new CarouselManager(this);

        this.dropdownManager = new DropdownManager(this);

        this.offcanvasManager = new OffcanvasManager(this);

        this.popoverManager = new PopoverManager(this);

        this.init();
    }

    async init() {
        await this.fontManager.init();
        await this.iconManager.init();
        this.styleManager.initializeStyleSheet();
        this.styleManager.addDefaultStyles();
        this.domManager.setupObservers();
        this.domManager.processAllElements();
        this.carouselManager.init();
        this.modalManager.init();
        this.popoverManager.init();
        this.scrollspyManager.init();
        this.toastManager.init();
        this.tooltipManager.init();
        this.headerManager.init();
        this.dropdownManager.init();
        this.offcanvasManager.init();
    }

    // Keep only core coordination methods
    static get properties() {
        return properties;
    }
    static get breakpoints() {
        return breakpoints;
    }
    static get containerMaxWidths() {
        return containerMaxWidths;
    }
    static get CLASS_REGEX() {
        return CLASS_REGEX;
    }
    static get COLOR_REGEX() {
        return COLOR_REGEX;
    }
}
