//node generate-fonts-manifest.js --fonts /public/fonts/ --manifest /public/js/fonts-manifest.json
//format de nommage correct : NomDeLaPolice-Weight.format
// public/fonts/
//   Roboto/
//     Roboto-Bold.woff2
//     Roboto-Medium.woff2
//   Open Sans/
//     OpenSans-Regular.woff2
//     OpenSans-Bold.woff2

import { FontsConfig } from "../utils/config.js";
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

function parseArgs() {
  const args = process.argv.slice(2);
  const config = {};

  for (let i = 0; i < args.length; i++) {
    if (args[i] === "--fonts" && args[i + 1]) {
      config.fontsDir = args[i + 1];
      config.fontsDir = path.join(
        path.resolve(__dirname, "../.."),
        config.fontsDir
      );
      i++;
    } else if (args[i] === "--manifest" && args[i + 1]) {
      config.manifestPath = args[i + 1];
      config.manifestPath = path.join(
        path.resolve(__dirname, "../.."),
        config.manifestPath
      );
      i++;
    }
  }

  return config;
}

function getConfig() {
  const projectRoot = path.resolve(__dirname, "../..");
  const args = parseArgs();
  const defaultConfig = {
    fontsDir:
      path.join(projectRoot, args.fontsDir) ||
      path.join(projectRoot, FontsConfig.fontsPath),
    manifestPath:
      path.join(projectRoot, args.manifestPath) ||
      path.join(projectRoot, FontsConfig.manifestPath),
    formats: [".woff2", ".woff", ".ttf"],
    weightMap: {
      thin: 100,
      extralight: 200,
      light: 300,
      regular: 400,
      medium: 500,
      semibold: 600,
      bold: 700,
      extrabold: 800,
      black: 900,
    },
  };

  return {
    ...defaultConfig,
    ...args,
  };
}

function ensureDirectories(config) {
  if (!fs.existsSync(config.fontsDir)) {
    fs.mkdirSync(config.fontsDir, { recursive: true });
    console.log("✅ Dossier des polices créé:", config.fontsDir);
  }

  const manifestDir = path.dirname(config.manifestPath);
  if (!fs.existsSync(manifestDir)) {
    fs.mkdirSync(manifestDir, { recursive: true });
    console.log("✅ Dossier du manifest créé:", manifestDir);
  }
}

function getAllFontFiles(dir) {
  let results = [];
  const items = fs.readdirSync(dir, { withFileTypes: true });

  for (const item of items) {
    const fullPath = path.join(dir, item.name);
    if (item.isDirectory()) {
      results = results.concat(getAllFontFiles(fullPath));
    } else {
      results.push({
        file: item.name,
        dir: dir,
        familyDir: path.basename(dir),
      });
    }
  }

  return results;
}

function parseFontFile(fileInfo, config) {
  console.log(`\n📝 Analyse du fichier: ${fileInfo.file}`);

  const [base, ext] = fileInfo.file.split(".");
  const parts = base.split("-");

  console.log(`   Base: ${base}`);
  console.log(`   Extension: ${ext}`);
  console.log(`   Dossier parent: ${fileInfo.familyDir}`);

  let style = "normal";
  let weight = 400;

  const type = ext === "woff2" ? "woff2" : ext === "woff" ? "woff" : "truetype";

  // Le dernier élément après le dernier tiret est généralement le poids ou le style
  const lastPart = parts[parts.length - 1].toLowerCase();
  if (config.weightMap[lastPart]) {
    weight = config.weightMap[lastPart];
    console.log(`   Poids détecté: ${weight}`);
  } else if (lastPart === "italic") {
    style = "italic";
    console.log(`   Style détecté: italic`);
  }

  // Utiliser le nom du dossier parent comme nom de famille de police
  const family = fileInfo.familyDir;
  console.log(`   Famille finale: ${family}`);

  return {
    family,
    weight,
    style,
    fullPath: path.join(fileInfo.dir, fileInfo.file),
    type: type,
  };
}

function generateManifest() {
  try {
    const config = getConfig();

    console.log("\n📁 Configuration:");
    console.log(`   Dossier des polices: ${config.fontsDir}`);
    console.log(`   Fichier manifest: ${config.manifestPath}`);

    ensureDirectories(config);

    console.log("\n🔍 Lecture récursive du dossier des polices...");
    const files = getAllFontFiles(config.fontsDir);
    console.log(`   ${files.length} fichiers trouvés`);

    const manifest = {};

    files.forEach((fileInfo) => {
      console.log(`\n📄 Traitement du fichier: ${fileInfo.file}`);

      if (config.formats.some((format) => fileInfo.file.endsWith(format))) {
        console.log(`   ✅ Format supporté`);
        const { family, weight, style, fullPath, type } = parseFontFile(
          fileInfo,
          config
        );

        if (!manifest[family]) {
          console.log(`   ➕ Nouvelle famille de police: ${family}`);
          manifest[family] = {};
        }

        if (!manifest[family][weight]) {
          console.log(`   ➕ Nouveau poids pour ${family}: ${weight}`);
          manifest[family][weight] = {
            style,
            weight,
            formats: [],
          };
        }

        const relativePath = path
          .relative(path.dirname(config.manifestPath), fullPath)
          .replace(/\\/g, "/");

        console.log(`   ➕ Ajout du format: ${type}`);
        manifest[family][weight].formats.push({
          file: relativePath,
          type,
        });
      } else {
        console.log(`   ❌ Format non supporté`);
      }
    });

    console.log("\n📝 Écriture du manifest...");
    fs.writeFileSync(config.manifestPath, JSON.stringify(manifest, null, 2));

    console.log("\n✅ Manifest généré avec succès");
    console.log("   Contenu du manifest :");
    console.log(JSON.stringify(manifest, null, 2));
  } catch (error) {
    console.error("\n❌ Erreur lors de la génération du manifeste:", error);
    process.exit(1);
  }
}

generateManifest();
