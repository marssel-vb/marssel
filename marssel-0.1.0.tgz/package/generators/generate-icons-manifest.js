//node generate-icons-manifest.js
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

function parseArgs() {
    const args = process.argv.slice(2);
    const config = {};

    for (let i = 0; i < args.length; i++) {
        if (args[i] === "--icons" && args[i + 1]) {
            config.customIconsDir = args[i + 1];
            i++;
        } else if (args[i] === "--manifest" && args[i + 1]) {
            config.manifestPath = args[i + 1];
            i++;
        }
    }

    return config;
}

function getConfig() {
    const projectRoot = path.resolve(__dirname, "../..");
    const args = parseArgs();

    const defaultConfig = {
        customIconsDir: path.join(projectRoot, "/public/images/icons/"),
        manifestPath: path.join(projectRoot, "/public/js/icons-manifest.json"),
    };

    if (args.customIconsDir) {
        args.customIconsDir = path.join(projectRoot, args.customIconsDir);
    }
    if (args.manifestPath) {
        args.manifestPath = path.join(projectRoot, args.manifestPath);
    }

    return {
        ...defaultConfig,
        ...args,
    };
}

const extractSvgProperties = (filePath, type) => {
    const content = fs.readFileSync(filePath, "utf8");

    // Nettoyage du SVG pour éviter les espaces inutiles
    const cleanedSvg = content.replace(/\s+/g, " ").trim();

    return {
        svg: cleanedSvg,
        type: type,
    };
};

// const extractSvgProperties = (filePath, type) => {
//     const content = fs.readFileSync(filePath, "utf8");

//     // Extract viewBox
//     const viewBoxMatch = content.match(/viewBox="([^"]+)"/);
//     const viewBox = viewBoxMatch ? viewBoxMatch[1] : "0 0 24 24";

//     if (type === "duotone") {
//         // Pour les icônes duotone, on extrait deux groupes de paths
//         const primaryPaths = [];
//         const secondaryPaths = [];

//         // Regex pour extraire les paths avec leurs attributs
//         const pathRegex = /<path([^>]*)d="([^"]+)"([^>]*)>/g;
//         let match;

//         while ((match = pathRegex.exec(content)) !== null) {
//             const attributes = match[1] + match[3];
//             const path = match[2];

//             // Si le path a une opacité spécifiée comme secondaire
//             if (
//                 attributes.includes('opacity="0.4"') ||
//                 attributes.includes('data-opacity="0.4"')
//             ) {
//                 secondaryPaths.push(path);
//             } else {
//                 primaryPaths.push(path);
//             }
//         }

//         return {
//             viewBox,
//             paths: {
//                 primary: primaryPaths.join(" "),
//                 secondary: secondaryPaths.join(" "),
//             },
//             ...ICON_STYLES[type],
//         };
//     } else {
//         // Pour les icônes normales (outline et solid)
//         const paths = [];
//         const pathRegex = /<path[^>]*d="([^"]+)"[^>]*>/g;
//         let match;

//         while ((match = pathRegex.exec(content)) !== null) {
//             paths.push(match[1]);
//         }

//         return {
//             viewBox,
//             path: paths.join(" "),
//             ...ICON_STYLES[type],
//         };
//     }
// };

async function loadDefaultIcons(projectRoot) {
    const defaultIconsPath = "./default-icons.js";
    try {
        const { icons } = await import(defaultIconsPath);
        return icons || {};
    } catch (error) {
        console.warn(
            "⚠️ Impossible de charger les icônes par défaut :",
            error.message
        );
        return {};
    }
}

// const processIconsInDirectory = (directory, type, manifest) => {
//     if (!fs.existsSync(directory)) {
//         console.log(`   📁 Creating directory: ${directory}`);
//         fs.mkdirSync(directory, { recursive: true });
//         return;
//     }

//     const files = fs
//         .readdirSync(directory)
//         .filter((file) => file.endsWith(".svg"));

//     for (const file of files) {
//         const baseName = path.basename(file, ".svg");
//         const filePath = path.join(directory, file);
//         const iconName =
//             type === "solid"
//                 ? `${baseName}-solid`
//                 : type === "duotone"
//                 ? `${baseName}-duotone`
//                 : baseName;
//         const properties = extractSvgProperties(filePath, type);

//         manifest[iconName] = properties;
//         console.log(`   ✅ Processed: ${file} (${type})`);
//     }
// };

const processIconsInDirectory = (directory, type, manifest) => {
    if (!fs.existsSync(directory)) {
        console.log(`📁 Creating directory: ${directory}`);
        fs.mkdirSync(directory, { recursive: true });
        return;
    }

    const files = fs
        .readdirSync(directory)
        .filter((file) => file.endsWith(".svg"));

    for (const file of files) {
        const baseName = path.basename(file, ".svg");
        const filePath = path.join(directory, file);

        const iconName =
            type === "solid"
                ? `${baseName}-solid`
                : type === "duotone"
                ? `${baseName}-duotone`
                : baseName;

        // On récupère directement le SVG brut
        const { svg } = extractSvgProperties(filePath, type);

        // On stocke le SVG directement dans le manifest
        manifest[iconName] = { svg, type };
        console.log(`✅ Processed: ${file} (${type})`);
    }
};

// Fonction principale pour générer le manifeste et le fichier d'icônes
const generateIconsManifest = async () => {
    try {
        const config = getConfig();

        console.log("\n📁 Configuration:");
        console.log(`   Icons directory: ${config.customIconsDir}`);
        console.log(`   Manifest file: ${config.manifestPath}`);

        const manifestDir = path.dirname(config.manifestPath);
        if (!fs.existsSync(manifestDir)) {
            fs.mkdirSync(manifestDir, { recursive: true });
        }

        const defaultIcons = await loadDefaultIcons(
            path.resolve(__dirname, "../..")
        );
        const manifest = { ...defaultIcons };

        console.log("\n🔍 Processing outline icons...");
        processIconsInDirectory(
            path.join(config.customIconsDir, "outline"),
            "outline",
            manifest
        );

        console.log("\n🔍 Processing solid icons...");
        processIconsInDirectory(
            path.join(config.customIconsDir, "solid"),
            "solid",
            manifest
        );

        console.log("\n🔍 Processing duotone icons...");
        processIconsInDirectory(
            path.join(config.customIconsDir, "duotone"),
            "duotone",
            manifest
        );

        fs.writeFileSync(
            config.manifestPath,
            JSON.stringify(manifest, null, 2)
        );

        const totalIcons =
            Object.keys(manifest).length - Object.keys(defaultIcons).length;
        console.log("\n✨ Generation completed successfully!");
        console.log(`   Number of custom icons processed: ${totalIcons}`);
        console.log(`   Manifest generated: ${config.manifestPath}`);
    } catch (error) {
        console.error("\n❌ Error generating manifest:", error);
        process.exit(1);
    }
};

// Exécuter le script
generateIconsManifest();

export default generateIconsManifest;
