import { CarouselStyles } from "../styles/CarouselStyles.js";

export class CarouselManager {
    constructor(marssel) {
        this.marssel = marssel;
        this.carouselStyles = new CarouselStyles(marssel.styleManager);

        this.carousels = new Map();
        this.activeCarousel = null;
        this.touchStartX = 0;
        this.touchEndX = 0;
    }

    init() {
        // Vérifie s'il y a au moins un trigger
        const hasCarousel = document.querySelector("[class*='carousel-']");
        if (!hasCarousel) return;

        // Add default styles
        this.carouselStyles.addBaseStyles();

        // Find and initialize all carousels in the DOM
        document.querySelectorAll("[class*='carousel-']").forEach((element) => {
            this.initializeCarousel(element);
        });

        // Set up the mutation observer to catch new carousels added to the DOM
        this.setupObserver();

        // Set up global event listeners
        this.setupEventListeners();
    }

    setupObserver() {
        // Use MutationObserver to detect new carousels added to the DOM
        const observer = new MutationObserver((mutations) => {
            mutations.forEach((mutation) => {
                if (mutation.type === "childList") {
                    mutation.addedNodes.forEach((node) => {
                        if (node.nodeType === 1) {
                            // Element node
                            // Check if the added node is a carousel or contains carousels
                            if (
                                node.classList &&
                                Array.from(node.classList).some((cls) =>
                                    cls.startsWith("carousel-")
                                )
                            ) {
                                this.initializeCarousel(node);
                            }

                            // Also check child elements for carousels
                            node.querySelectorAll(
                                "[class*='carousel-']"
                            ).forEach((element) => {
                                this.initializeCarousel(element);
                            });
                        }
                    });
                }
            });
        });

        observer.observe(document.body, {
            childList: true,
            subtree: true,
        });
    }

    setupEventListeners() {
        // Global event listener for touch events (for swipe functionality)
        document.addEventListener(
            "touchstart",
            (e) => {
                this.touchStartX = e.touches[0].clientX;
            },
            { passive: true }
        );

        document.addEventListener(
            "touchend",
            (e) => {
                this.touchEndX = e.changedTouches[0].clientX;
                if (this.activeCarousel) {
                    const swipeDistance = this.touchEndX - this.touchStartX;
                    const carousel = this.carousels.get(this.activeCarousel);

                    if (swipeDistance > 50) {
                        // Swipe right - go to previous slide
                        carousel.prevSlide();
                    } else if (swipeDistance < -50) {
                        // Swipe left - go to next slide
                        carousel.nextSlide();
                    }
                }
            },
            { passive: true }
        );

        // Set activeCarousel when user interacts with a carousel
        document.addEventListener(
            "mouseenter",
            (e) => {
                const path = e.composedPath();
                const carouselContainer = path.find(
                    (el) =>
                        el instanceof HTMLElement &&
                        el.classList.contains("carousel-container")
                );

                if (carouselContainer) {
                    const carouselId = carouselContainer.dataset.carouselId;
                    if (carouselId && this.carousels.has(carouselId)) {
                        this.activeCarousel = carouselId;
                    }
                }
            },
            true
        );

        document.addEventListener(
            "touchstart",
            (e) => {
                if (e.target.closest(".carousel-container")) {
                    const carouselId = e.target.closest(".carousel-container")
                        .dataset.carouselId;
                    if (carouselId && this.carousels.has(carouselId)) {
                        this.activeCarousel = carouselId;
                    }
                }
            },
            { passive: true }
        );
    }

    initializeCarousel(element) {
        // Check if this is actually a carousel container
        if (!element.classList.contains("carousel-container")) {
            // Maybe it's a child of a carousel or has another carousel-related class
            // Let's find the closest carousel container if any
            const container = element.closest(".carousel-container");
            if (container) {
                element = container;
            } else {
                // Not a carousel-related element
                return;
            }
        }

        // Check if this carousel is already initialized
        if (
            element.dataset.carouselId &&
            this.carousels.has(element.dataset.carouselId)
        ) {
            return;
        }

        // Generate a unique ID for this carousel
        const carouselId = `carousel-${Date.now()}-${Math.floor(
            Math.random() * 1000
        )}`;
        element.dataset.carouselId = carouselId;

        // Create a new Carousel instance
        const carousel = new Carousel(element, this.marssel);

        // Initialize it
        carousel.init();

        // Store it in our carousels Map
        this.carousels.set(carouselId, carousel);
    }
}

class Carousel {
    constructor(element, marssel) {
        this.container = element;
        this.marssel = marssel;
        this.currentSlide = 0;
        this.autoplay = this.container.dataset.autoplay === "true";
        this.interval = parseInt(this.container.dataset.interval || "5000");
        this.autoplayTimer = null;
        this.slides = [];
        this.indicators = [];
    }

    init() {
        // Make sure the container has proper structure
        this.setupStructure();

        // Find all slides
        this.slides = Array.from(
            this.container.querySelectorAll(".carousel-slide")
        );

        // Set up navigation buttons
        this.setupNavigation();

        // Set up indicators
        this.setupIndicators();

        // Apply initial state
        this.goToSlide(0);

        // Start autoplay if enabled
        if (this.autoplay) {
            this.startAutoplay();
        }
    }

    setupStructure() {
        // Check if the container already has the expected structure
        if (!this.container.querySelector(".carousel-track")) {
            // Wrap all direct children in a track element
            const track = document.createElement("div");
            track.className = "carousel-track";

            // Get all original children
            const children = Array.from(this.container.children);

            // Move them to the track
            children.forEach((child) => {
                // Skip if it's a navigation button or indicators container
                if (
                    child.classList.contains("carousel-nav-button") ||
                    child.classList.contains("carousel-indicators")
                ) {
                    return;
                }

                // Wrap in a slide div if it's not already a slide
                if (!child.classList.contains("carousel-slide")) {
                    const slide = document.createElement("div");
                    slide.className = "carousel-slide";

                    // Move the child into the slide
                    slide.appendChild(child);

                    // Add the slide to the track
                    track.appendChild(slide);
                } else {
                    // It's already a slide, just move it to the track
                    track.appendChild(child);
                }
            });

            // Add the track to the container
            this.container.appendChild(track);
        }

        // Find all slides
        const slides = this.container.querySelectorAll(".carousel-slide");

        // Make sure each slide has captions if needed
        slides.forEach((slide) => {
            // Check for caption data attribute
            const captionText = slide.dataset.caption;
            if (captionText && !slide.querySelector(".carousel-caption")) {
                const caption = document.createElement("div");
                caption.className = "carousel-caption";
                caption.textContent = captionText;
                slide.appendChild(caption);
            }
        });
    }

    setupNavigation() {
        // Create previous button if it doesn't exist
        if (!this.container.querySelector(".carousel-prev")) {
            const prevButton = document.createElement("button");
            prevButton.className = "carousel-nav-button carousel-prev";
            prevButton.innerHTML = "&lsaquo;";
            prevButton.setAttribute("aria-label", "Previous slide");
            prevButton.addEventListener("click", () => this.prevSlide());
            this.container.appendChild(prevButton);
        } else {
            // Make sure the event listener is attached
            this.container
                .querySelector(".carousel-prev")
                .addEventListener("click", () => this.prevSlide());
        }

        // Create next button if it doesn't exist
        if (!this.container.querySelector(".carousel-next")) {
            const nextButton = document.createElement("button");
            nextButton.className = "carousel-nav-button carousel-next";
            nextButton.innerHTML = "&rsaquo;";
            nextButton.setAttribute("aria-label", "Next slide");
            nextButton.addEventListener("click", () => this.nextSlide());
            this.container.appendChild(nextButton);
        } else {
            // Make sure the event listener is attached
            this.container
                .querySelector(".carousel-next")
                .addEventListener("click", () => this.nextSlide());
        }
    }

    setupIndicators() {
        // Create indicators container if it doesn't exist
        let indicatorsContainer = this.container.querySelector(
            ".carousel-indicators"
        );

        if (!indicatorsContainer) {
            indicatorsContainer = document.createElement("div");
            indicatorsContainer.className = "carousel-indicators";
            this.container.appendChild(indicatorsContainer);
        } else {
            // Clear existing indicators
            indicatorsContainer.innerHTML = "";
        }

        // Create an indicator for each slide
        this.slides.forEach((slide, index) => {
            const indicator = document.createElement("span");
            indicator.className = "carousel-indicator";
            indicator.dataset.slideIndex = index;
            indicator.setAttribute("aria-label", `Go to slide ${index + 1}`);

            // Add click event
            indicator.addEventListener("click", () => this.goToSlide(index));

            // Add to container
            indicatorsContainer.appendChild(indicator);

            // Store in our indicators array
            this.indicators.push(indicator);
        });
    }

    startAutoplay() {
        // Clear any existing timer
        if (this.autoplayTimer) {
            clearInterval(this.autoplayTimer);
        }

        // Set up autoplay interval
        this.autoplayTimer = setInterval(() => {
            this.nextSlide();
        }, this.interval);

        // Pause on hover if needed
        if (this.container.dataset.pauseOnHover !== "false") {
            this.container.addEventListener("mouseenter", () => {
                clearInterval(this.autoplayTimer);
            });

            this.container.addEventListener("mouseleave", () => {
                if (this.autoplay) {
                    this.startAutoplay();
                }
            });
        }
    }

    goToSlide(index) {
        // Validate index
        if (index < 0) {
            index = this.slides.length - 1;
        } else if (index >= this.slides.length) {
            index = 0;
        }

        // Update current slide
        this.currentSlide = index;

        // Move the track to position
        const track = this.container.querySelector(".carousel-track");
        track.style.transform = `translateX(-${index * 100}%)`;

        // Update indicators
        this.indicators.forEach((indicator, i) => {
            if (i === index) {
                indicator.classList.add("active");
            } else {
                indicator.classList.remove("active");
            }
        });

        // If autoplay is on, reset the timer to give user time to view the new slide
        if (this.autoplay && this.autoplayTimer) {
            clearInterval(this.autoplayTimer);
            this.startAutoplay();
        }
    }

    nextSlide() {
        this.goToSlide(this.currentSlide + 1);
    }

    prevSlide() {
        this.goToSlide(this.currentSlide - 1);
    }
}
