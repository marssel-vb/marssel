import { parseClassName, parseClassPart } from "../utils/parsed.js";
import { cleanValue } from "../utils/helpers.js";

export class DomManager {
    constructor(marssel) {
        this.marssel = marssel;
    }

    setupObservers() {
        const observer = new MutationObserver((mutations) => {
            let needsUpdate = false;

            for (const mutation of mutations) {
                if (
                    mutation.type === "attributes" &&
                    mutation.attributeName === "class"
                ) {
                    this.processElement(mutation.target);
                    needsUpdate = true;
                } else if (mutation.type === "childList") {
                    mutation.addedNodes.forEach((node) => {
                        if (node.nodeType === 1) {
                            // Element node
                            this.processElement(node);
                            needsUpdate = true;
                        }
                    });
                }
            }

            if (needsUpdate) {
                this.marssel.styleManager.debounceStyleUpdate();
            }
        });

        observer.observe(document.body, {
            childList: true,
            subtree: true,
            attributes: true,
            attributeFilter: ["class"],
        });
    }

    processAllElements() {
        document
            .querySelectorAll("*")
            .forEach((element) => this.processElement(element));
    }

    processElement(element) {
        // Early return if not a valid HTML element
        if (!(element instanceof HTMLElement)) return;

        // Cache classList pour éviter les accès multiples
        const classList = Array.from(element.classList);

        // Filtrer uniquement les classes qui contiennent "-["
        const stylingClasses = classList.filter((className) =>
            className.includes("-[")
        );

        if (this.marssel.styleManager.lazyload) {
            // En mode lazy, on stocke les classes à traiter et on observe l'élément
            if (stylingClasses.length > 0) {
                this.marssel.styleManager.lazyElements.set(
                    element,
                    stylingClasses
                );
                this.marssel.styleManager.lazyObserver.observe(element);
            }
        } else {
            // Mode normal: traitement immédiat
            stylingClasses.forEach((className) => {
                if (className.includes("+")) {
                    this.processCombinedClass(className);
                } else {
                    this.processClassName(className);
                }
            });
        }
    }

    processCombinedClass(className) {
        // Vérifiez si c'est une classe de style composite (avec ---)
        const compositeParts = className.split("---");
        const componentName = compositeParts[0];
        let stylesPart = compositeParts[1];

        // Si pas de composant spécifique, traiter normalement
        if (!stylesPart) {
            // Split the class into its component parts
            const parts = className.split("+");

            // Get the breakpoint prefix from the first part if it exists
            let breakpointPrefix = "";
            let breakpoints = [];
            const firstPart = parts[0];

            if (firstPart.includes("--")) {
                const breakpointSection = firstPart.split("--")[0];
                breakpointPrefix = breakpointSection + "--";
                breakpoints = breakpointSection.split("--");
            }

            // Create a selector for the combined class
            const escapedClassName = className
                .replace(/\[/g, "\\[")
                .replace(/\]/g, "\\]")
                .replace(/\+/g, "\\+"); // Escape the + character as well
            const selector = `.${escapedClassName}`;

            // Collect all style declarations
            const declarations = new Set();

            parts.forEach((part, index) => {
                // For parts after the first one, add the breakpoint prefix if needed
                if (index > 0 && breakpointPrefix && !part.includes("--")) {
                    part = breakpointPrefix + part;
                }

                // Parse each part to get property and value
                const parsed = parseClassName(part);
                if (!parsed) return;

                // Get CSS declarations for this property and value
                const { property, value } = parsed;

                // Handle different property types (similar to your generateRule method)
                if (property === "bg" || property === "background-color") {
                    declarations.add(
                        `background-color: ${this.marssel.domManager.processColor(
                            value
                        )}`
                    );
                } else if (property === "c" || property === "color") {
                    declarations.add(
                        `color: ${this.marssel.domManager.processColor(value)}`
                    );
                } else {
                    // Add other property handling as needed
                    const cssProperty =
                        this.marssel.constructor.properties[property];
                    if (cssProperty) {
                        const cssValue = cleanValue(value);
                        if (Array.isArray(cssProperty)) {
                            cssProperty.forEach((prop) => {
                                declarations.add(`${prop}: ${cssValue}`);
                            });
                        } else {
                            declarations.add(`${cssProperty}: ${cssValue}`);
                        }
                    }
                }
            });

            // Add all declarations to the combined selector
            this.marssel.styleManager.addDeclarationsWithMediaQuery(
                breakpoints,
                selector,
                declarations
            );
        } else {
            // Traitement des styles composite avec "---"
            // Create a selector for the component
            const selector = `.${componentName}`;

            // Collect all style declarations
            const declarations = new Set();

            // Split combined styles
            const styleClasses = stylesPart.split("+").filter(Boolean);

            // Parse each style part
            styleClasses.forEach((stylePart) => {
                // Parse each part to get property and value
                const parsed = parseClassPart(componentName, stylePart);
                if (!parsed) return;

                // Get CSS declarations for this property and value
                const { property, value, breakpoints } = parsed;

                // Handle different property types
                if (property === "bg" || property === "background-color") {
                    declarations.add(
                        `background-color: ${this.marssel.domManager.processColor(
                            value
                        )}`
                    );
                } else if (property === "c" || property === "color") {
                    declarations.add(
                        `color: ${this.marssel.domManager.processColor(value)}`
                    );
                } else {
                    // Add other property handling as needed
                    const cssProperty =
                        this.marssel.constructor.properties[property];
                    if (cssProperty) {
                        const cssValue = cleanValue(value);
                        if (Array.isArray(cssProperty)) {
                            cssProperty.forEach((prop) => {
                                declarations.add(`${prop}: ${cssValue}`);
                            });
                        } else {
                            declarations.add(`${cssProperty}: ${cssValue}`);
                        }
                    }
                }
            });

            // Get breakpoints from the first style part if any
            let breakpoints = [];
            if (styleClasses.length > 0) {
                const firstParsed = parseClassPart(
                    componentName,
                    styleClasses[0]
                );
                if (firstParsed && firstParsed.breakpoints) {
                    breakpoints = firstParsed.breakpoints;
                }
            }

            // Add all declarations to the component selector
            this.marssel.styleManager.addDeclarationsWithMediaQuery(
                breakpoints,
                selector,
                declarations
            );
        }
    }

    processClassName(className) {
        // Vérifie si c'est une classe de style composite (avec ---)
        const parts = className.split("---");
        const componentName = parts[0];
        let stylesPart = parts[1];

        if (!stylesPart) {
            // Cas simple : pas de composant spécifique
            this.processSingleStyle(className);
            return;
        }

        // Vérifier si nous avons un groupe de styles avec un pseudo-modificateur commun
        const groupedMatch = stylesPart.match(
            /^\[(.*)\]-([a-z-]+(?:-[a-z-]+)*)$/
        );
        if (groupedMatch) {
            const groupedStyles = groupedMatch[1].split("+").filter(Boolean);
            const sharedModifier = groupedMatch[2];

            groupedStyles.forEach((style) => {
                // Ajouter le modificateur commun à chaque style
                const fullStyle = `${style}-${sharedModifier}`;
                const parsed = parseClassPart(componentName, fullStyle);

                if (parsed) {
                    this.marssel.styleManager.addStyleRule(parsed);
                }
            });
            return;
        }

        // Traitement des styles multiples standard
        const styleClasses = stylesPart.split("+").filter(Boolean);
        styleClasses.forEach((styleClass) => {
            const parsed = parseClassPart(componentName, styleClass);

            if (parsed) {
                this.marssel.styleManager.addStyleRule(parsed);
            }
        });
    }

    processSingleStyle(className) {
        const parsed = parseClassName(className);

        if (parsed) {
            this.marssel.styleManager.addStyleRule(parsed);
        }
    }

    processColor(value, type) {
        if (this.marssel.constructor.COLOR_REGEX.HEX.test(value)) {
            return `#${value}`;
        } else if (this.marssel.constructor.COLOR_REGEX.RGB.test(value)) {
            const [r, g, b] = value.split(/\s+/);
            return `rgb(${r}, ${g}, ${b})`;
        } else if (this.marssel.constructor.COLOR_REGEX.RGBA.test(value)) {
            const [r, g, b, a] = value.split(/\s+/);
            const alpha = parseInt(a) > 1 ? parseInt(a) / 100 : a;
            return `rgba(${r}, ${g}, ${b}, ${alpha})`;
        }
        return value;
    }
}
