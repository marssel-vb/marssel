import { DropdownStyles } from "../styles/DropdownStyles.js";

export class DropdownManager {
    constructor(marssel) {
        this.marssel = marssel;
        this.dropdowns = new Map();
        this.currentBreakpoint = this.getCurrentBreakpoint();
        this.dropdownStyles = new DropdownStyles(marssel.styleManager);
    }

    init() {
        const hasDropdown = document.querySelector(".dropdown");
        if (!hasDropdown) return;

        // Add default styles
        this.dropdownStyles.addBaseStyles();

        // Initialiser tous les dropdowns avec la classe .dropdown
        document.querySelectorAll(".dropdown").forEach((dropdown) => {
            this.initializeDropdown(dropdown);
        });

        // Initialiser tous les dropdowns fullwidth
        document.querySelectorAll(".dropdown-fullwidth").forEach((dropdown) => {
            this.initializeFullwidthDropdown(dropdown);
        });

        // Initialiser l'écoute des changements de taille de fenêtre
        window.addEventListener("resize", this.handleResize.bind(this));

        // Fermer les dropdowns quand on clique en dehors
        document.addEventListener("click", (e) => {
            this.closeAllDropdowns(e.target);
        });
    }

    initializeDropdown(dropdownElement) {
        const dropdownId =
            dropdownElement.id || `dropdown-${this.dropdowns.size + 1}`;
        if (!dropdownElement.id) {
            dropdownElement.id = dropdownId;
        }

        // Récupérer les configurations
        const config = {
            position: dropdownElement.dataset.position || "bottom-left", // "bottom-left", "bottom-right", "top-left", etc.
            animation: dropdownElement.dataset.animation || "fade", // "fade", "slide", etc.
            closeOnClick: dropdownElement.dataset.closeOnClick !== "false", // Par défaut true
        };

        // Initialiser le bouton toggle
        const toggle = dropdownElement.querySelector(".dropdown-toggle");
        const menu = dropdownElement.querySelector(".dropdown-menu");

        if (toggle && menu) {
            toggle.addEventListener("click", (e) => {
                e.preventDefault();
                e.stopPropagation();

                // Toggle dropdown
                this.toggleDropdown(dropdownId);
            });
        }

        // Initialiser les sous-menus si nécessaire
        this.initializeSubmenu(dropdownElement);

        // Stocker la configuration
        this.dropdowns.set(dropdownId, {
            element: dropdownElement,
            config: config,
            isOpen: false,
            menu: menu,
            toggle: toggle,
        });
    }

    initializeFullwidthDropdown(dropdownElement) {
        const dropdownId =
            dropdownElement.id ||
            `dropdown-fullwidth-${this.dropdowns.size + 1}`;
        if (!dropdownElement.id) {
            dropdownElement.id = dropdownId;
        }

        // Récupérer les configurations spécifiques aux fullwidth dropdowns
        const config = {
            animation: dropdownElement.dataset.animation || "fade",
            closeOnClick: dropdownElement.dataset.closeOnClick !== "false",
            container: dropdownElement.dataset.container || "parent", // "parent", "body", etc.
        };

        // Initialiser le bouton toggle
        const toggle = dropdownElement.querySelector(".dropdown-toggle");
        const menu = dropdownElement.querySelector(".dropdown-menu-fullwidth");

        if (toggle && menu) {
            toggle.addEventListener("click", (e) => {
                e.preventDefault();
                e.stopPropagation();

                // Toggle fullwidth dropdown
                this.toggleFullwidthDropdown(dropdownId);
            });
        }

        // Stocker la configuration
        this.dropdowns.set(dropdownId, {
            element: dropdownElement,
            config: config,
            isOpen: false,
            menu: menu,
            toggle: toggle,
            isFullwidth: true,
        });
    }

    initializeSubmenu(dropdownElement) {
        // Gestion des sous-menus multiniveaux
        dropdownElement
            .querySelectorAll(".dropdown-submenu > a")
            .forEach((submenuToggle) => {
                submenuToggle.addEventListener("click", (e) => {
                    e.preventDefault();
                    e.stopPropagation();

                    const submenu = submenuToggle.nextElementSibling;
                    const parentItem = submenuToggle.parentElement;

                    // Toggle submenu
                    const isActive = parentItem.classList.contains("active");

                    // Fermer les autres sous-menus du même niveau
                    const siblings = Array.from(
                        parentItem.parentElement.children
                    );
                    siblings.forEach((sibling) => {
                        if (
                            sibling !== parentItem &&
                            sibling.classList.contains("active")
                        ) {
                            sibling.classList.remove("active");
                            const siblingSubmenu =
                                sibling.querySelector(".dropdown-menu");
                            if (siblingSubmenu)
                                siblingSubmenu.style.display = "none";
                        }
                    });

                    // Basculer l'état actuel
                    parentItem.classList.toggle("active", !isActive);
                    if (submenu) {
                        submenu.style.display = isActive ? "none" : "block";
                    }
                });
            });
    }

    toggleDropdown(dropdownId) {
        const dropdown = this.dropdowns.get(dropdownId);
        if (!dropdown || !dropdown.menu) return;

        const { element, menu, isOpen } = dropdown;

        // Fermer tous les autres dropdowns d'abord
        this.closeAllDropdowns(element);

        // Inverser l'état actuel
        const newState = !isOpen;

        if (newState) {
            this.openDropdown(dropdownId);
        } else {
            this.closeDropdown(dropdownId);
        }
    }

    toggleFullwidthDropdown(dropdownId) {
        const dropdown = this.dropdowns.get(dropdownId);
        if (!dropdown || !dropdown.menu || !dropdown.isFullwidth) return;

        const { element, menu, isOpen } = dropdown;

        // Fermer tous les autres dropdowns d'abord
        this.closeAllDropdowns(element);

        // Inverser l'état actuel
        const newState = !isOpen;

        if (newState) {
            this.openDropdown(dropdownId);
        } else {
            this.closeDropdown(dropdownId);
        }
    }

    openDropdown(dropdownId) {
        const dropdown = this.dropdowns.get(dropdownId);
        if (!dropdown || dropdown.isOpen) return;

        const { element, menu } = dropdown;

        // Mettre à jour l'état visuel
        element.classList.add("active");
        menu.style.display = "block";

        // Mettre à jour l'état stocké
        this.dropdowns.set(dropdownId, {
            ...dropdown,
            isOpen: true,
        });
    }

    closeDropdown(dropdownId) {
        const dropdown = this.dropdowns.get(dropdownId);
        if (!dropdown || !dropdown.isOpen) return;

        const { element, menu } = dropdown;

        // Mettre à jour l'état visuel
        element.classList.remove("active");
        menu.style.display = "none";

        // Mettre à jour l'état stocké
        this.dropdowns.set(dropdownId, {
            ...dropdown,
            isOpen: false,
        });
    }

    closeAllDropdowns(exceptElement = null) {
        this.dropdowns.forEach((dropdown, id) => {
            if (
                dropdown.isOpen &&
                dropdown.element !== exceptElement &&
                !dropdown.element.contains(exceptElement)
            ) {
                this.closeDropdown(id);
            }
        });
    }

    getCurrentBreakpoint() {
        const width = window.innerWidth;
        if (width < 576) return "xs";
        if (width < 768) return "sm";
        if (width < 992) return "md";
        if (width < 1200) return "lg";
        return "xl";
    }

    handleResize() {
        const newBreakpoint = this.getCurrentBreakpoint();

        // Si le breakpoint a changé
        if (newBreakpoint !== this.currentBreakpoint) {
            this.currentBreakpoint = newBreakpoint;

            // Fermer tous les dropdowns ouverts lors d'un changement de breakpoint
            this.dropdowns.forEach((dropdown, id) => {
                if (dropdown.isOpen) {
                    this.closeDropdown(id);
                }
            });
        }
    }

    // Méthode pour mettre à jour la configuration d'un dropdown
    updateDropdownConfig(dropdownId, newConfig) {
        const dropdown = this.dropdowns.get(dropdownId);
        if (!dropdown) return;

        // Mettre à jour la configuration
        this.dropdowns.set(dropdownId, {
            ...dropdown,
            config: { ...dropdown.config, ...newConfig },
        });
    }

    // Méthode pour positionner correctement un dropdown en fonction de ses options
    positionDropdown(dropdownId) {
        const dropdown = this.dropdowns.get(dropdownId);
        if (!dropdown || !dropdown.isOpen) return;

        const { element, menu, config } = dropdown;

        // Réinitialiser les styles de positionnement
        menu.style.top = "";
        menu.style.left = "";
        menu.style.right = "";
        menu.style.bottom = "";

        // Si c'est un dropdown fullwidth, pas besoin de positionnement personnalisé
        if (dropdown.isFullwidth) return;

        // Appliquer le positionnement en fonction de la configuration
        switch (config.position) {
            case "bottom-right":
                menu.style.top = "100%";
                menu.style.right = "0";
                break;
            case "top-left":
                menu.style.bottom = "100%";
                menu.style.left = "0";
                break;
            case "top-right":
                menu.style.bottom = "100%";
                menu.style.right = "0";
                break;
            case "left-top":
                menu.style.right = "100%";
                menu.style.top = "0";
                break;
            case "left-bottom":
                menu.style.right = "100%";
                menu.style.bottom = "0";
                break;
            case "right-top":
                menu.style.left = "100%";
                menu.style.top = "0";
                break;
            case "right-bottom":
                menu.style.left = "100%";
                menu.style.bottom = "0";
                break;
            default: // "bottom-left" est la valeur par défaut
                menu.style.top = "100%";
                menu.style.left = "0";
        }
    }
}
