import { FontsConfig } from "../utils/config.js";

export class FontManager {
    constructor(marssel) {
        this.marssel = marssel;
        this.config = {
            fontsPath: FontsConfig.fontsPath,
            manifestUrl: FontsConfig.manifestPath,
            loaded: new Set(),
            manifest: null,
            pendingRequests: new Map(),
            googleTimeout: 50,
            googleFontsUrl: "https://fonts.googleapis.com/css2",
        };
    }

    async loadManifest() {
        try {
            const response = await fetch(this.config.manifestUrl);
            this.config.manifest = await response.json();
        } catch (error) {
            console.warn("Erreur chargement manifeste polices:", error);
            this.config.manifest = {};
        }
    }

    async init() {
        await this.loadManifest();
    }

    async handleFont(fontFamily, variant = "400") {
        const fontKey = `${fontFamily}-${variant}`;
        console.log("handleFont called with:", fontFamily, variant);

        if (this.config.loaded.has(fontKey)) return;
        this.config.loaded.add(fontKey);

        if (this.config.manifest?.[fontFamily]?.[variant]) {
            this.injectLocalFont(fontFamily, variant);
        } else {
            this.loadGoogleFont(fontFamily, variant);
        }
    }

    injectLocalFont(fontFamily, variant) {
        const fontData = this.config.manifest[fontFamily][variant];
        const src = fontData.formats
            .map((format) => {
                let formatType = "woff2";
                if (format.file.endsWith(".woff")) formatType = "woff";
                if (format.file.endsWith(".ttf")) formatType = "truetype";

                return `url('${format.file}') format('${formatType}')`;
            })
            .join(", ");

        const cssText = `
            @font-face {
                font-family: '${fontFamily}';
                font-style: ${fontData.style};
                font-weight: ${fontData.weight};
                font-display: swap;
                src: ${src};
            }
        `;
        this.marssel.styleManager.addFontFace(cssText);
    }

    loadGoogleFont(family, variant) {
        const [weight = "400", style = "normal"] = variant.split("_");
        const familyKey = family.replace(/ /g, "+");
        const variantKey = style === "italic" ? `1,${weight}` : `0,${weight}`;

        const existing =
            this.config.pendingRequests.get(familyKey) || new Set();
        existing.add(variantKey);
        this.config.pendingRequests.set(familyKey, existing);

        clearTimeout(this.googleTimer);
        this.googleTimer = setTimeout(
            () => this.flushGoogleFonts(),
            this.config.googleTimeout
        );
    }

    flushGoogleFonts() {
        if (this.config.pendingRequests.size === 0) return;

        // Construire une seule URL avec toutes les familles et leurs variantes
        const fontParams = Array.from(this.config.pendingRequests.entries())
            .map(
                ([family, variants]) =>
                    `${family}:ital,wght@${Array.from(variants).join(";")}`
            )
            .join("&family=");

        const url = `${this.config.googleFontsUrl}?family=${fontParams}&display=swap`;

        // Vérifier si un lien avec cette URL existe déjà
        if (
            [...document.head.querySelectorAll("link[rel='stylesheet']")].some(
                (link) => link.href === url
            )
        ) {
            console.log("Les polices sont déjà chargées.");
            return;
        }

        // Ajouter un seul <link> pour toutes les polices
        const link = document.createElement("link");
        link.rel = "stylesheet";
        link.href = url;
        document.head.appendChild(link);
        console.log("Police(s) chargée(s):", link.href);

        // Nettoyer la liste des requêtes en attente
        this.config.pendingRequests.clear();
    }

    /*generateFontRule(parsed) {
        console.log("generateFontRule");
        if (!this.config.manifest) {
            // Vérifier si le manifeste est chargé
            console.error("FontManager non initialisé");
            return "";
        }
        const match = parsed.value.match(/(.*?)\[(\d+)(?:_(.*?))?\]/);
        if (!match) return "";

        const fontFamily = match[1].replace(/_/g, " ");
        const fontWeight = match[2];
        const fontStyle = match[3] === "italic" ? "italic" : "normal";

        this.handleFont(fontFamily, fontWeight);

        const selector = this.marssel.styleManager.buildSelector(parsed);
        console.log(selector);
        const declarations = [
            `font-family: '${fontFamily}', sans-serif`,
            `font-weight: ${fontWeight}`,
            `font-style: ${fontStyle}`,
        ].join("; ");

        return this.marssel.styleManager.wrapWithMediaQuery(
            selector,
            declarations,
            parsed.breakpoints
        );
    }*/
}
