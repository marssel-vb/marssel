import { HeaderStyles } from "../styles/HeaderStyles.js";

export class HeaderManager {
    constructor(marssel) {
        this.marssel = marssel;
        this.headers = new Map();
        this.currentBreakpoint = this.getCurrentBreakpoint();
        this.bodyScrollLock = false;
        this.headerStyles = new HeaderStyles(marssel.styleManager);
        this.dropdownManager = marssel.dropdownManager;
    }

    init() {
        const headerElement = document.getElementById("main-header");
        if (!headerElement) return;

        // Add default styles
        this.headerStyles.addBaseStyles();

        // Initialiser tous les headers avec la classe ".header
        document.querySelectorAll(".header").forEach((header) => {
            this.initializeHeader(header);
        });

        // Initialiser l'écoute des changements de taille de fenêtre
        window.addEventListener("resize", this.handleResize.bind(this));

        // Fermer les menus quand on clique en dehors
        document.addEventListener("click", (e) => {
            this.headers.forEach((header, id) => {
                if (header.isOpen) {
                    // Vérifier si le clic est en dehors du header et du menu mobile
                    const headerElement = header.element;
                    const mobileMenu =
                        headerElement.querySelector(".mobile-menu");

                    if (
                        !headerElement.contains(e.target) ||
                        (mobileMenu &&
                            !mobileMenu.contains(e.target) &&
                            !e.target.closest('[data-toggle="menu"]'))
                    ) {
                        this.closeMobileMenu(id);
                    }
                }
            });
        });

        // La gestion des dropdowns est maintenant déléguée au DropdownManager
        // Nous n'avons plus besoin des gestionnaires d'événements pour les dropdowns ici
    }

    initializeHeader(headerElement) {
        const headerId = headerElement.id || `header-${this.headers.size + 1}`;
        if (!headerElement.id) {
            headerElement.id = headerId;
        }

        // Récupérer les configurations
        const config = {
            logoPosition: headerElement.dataset.logoPosition || "left",
            navPosition: headerElement.dataset.navPosition || "center",
            actionPosition: headerElement.dataset.actionPosition || "right",
            mobileMenuType: headerElement.dataset.mobileMenuType || "sidebar",
            sidebarPosition: headerElement.dataset.sidebarPosition || "left",
            sidebarStyle: headerElement.dataset.sidebarStyle || "overlay",
        };

        // Créer le menu mobile s'il n'existe pas
        this.ensureMobileMenuExists(headerElement, config);

        // Initialiser les boutons toggle pour le mobile
        const toggleButtons = headerElement.querySelectorAll(
            '[data-toggle="menu"]'
        );
        toggleButtons.forEach((button) => {
            button.addEventListener("click", (e) => {
                e.preventDefault();
                this.toggleMobileMenu(headerId);
            });
        });

        // Nous ne initialisons plus les dropdowns ici - c'est géré par DropdownManager

        // Stocker la configuration
        this.headers.set(headerId, {
            element: headerElement,
            config: config,
            isOpen: false,
        });

        // Créer l'overlay si nécessaire
        this.ensureOverlayExists(headerElement);

        // Appliquer la configuration initiale
        this.applyLayoutConfig(headerId);
    }

    ensureMobileMenuExists(headerElement, config) {
        // Vérifier si le menu mobile existe déjà
        let mobileMenu = headerElement.querySelector(".mobile-menu");

        if (!mobileMenu) {
            // Créer le menu mobile avec la classe appropriée
            mobileMenu = document.createElement("div");
            mobileMenu.className = `mobile-menu ${config.mobileMenuType}`;

            // Cloner la navbar pour le menu mobile
            const navbar = headerElement.querySelector(".header-navbar");
            if (navbar) {
                const mobileNavbar = navbar.cloneNode(true);
                mobileMenu.appendChild(mobileNavbar);
            }

            // Ajouter un bouton de fermeture
            const closeButton = document.createElement("button");
            closeButton.className = "menu-close";
            closeButton.innerHTML = "&times;";
            closeButton.setAttribute("aria-label", "Close menu");
            closeButton.addEventListener("click", () => {
                this.closeMobileMenu(headerElement.id);
            });

            mobileMenu.prepend(closeButton);
            headerElement.appendChild(mobileMenu);
        }
    }

    ensureOverlayExists(headerElement) {
        // Vérifier si l'overlay existe déjà
        let overlay = headerElement.querySelector(".menu-overlay");

        if (!overlay) {
            overlay = document.createElement("div");
            overlay.className = "menu-overlay";
            overlay.addEventListener("click", () => {
                this.closeMobileMenu(headerElement.id);
            });

            headerElement.appendChild(overlay);
        }
    }

    // La méthode initializeDropdowns a été supprimée car elle est maintenant gérée par DropdownManager

    toggleMobileMenu(headerId) {
        const header = this.headers.get(headerId);
        if (!header) return;

        const { element, config, isOpen } = header;
        const mobileMenu = element.querySelector(".mobile-menu");
        const overlay = element.querySelector(".menu-overlay");

        if (!mobileMenu) return;

        // Inverser l'état
        const newState = !isOpen;

        if (newState) {
            this.openMobileMenu(headerId);
        } else {
            this.closeMobileMenu(headerId);
        }
    }

    openMobileMenu(headerId) {
        const header = this.headers.get(headerId);
        if (!header || header.isOpen) return;

        const { element, config } = header;
        const mobileMenu = element.querySelector(".mobile-menu");
        const overlay = element.querySelector(".menu-overlay");
        const toggleButton = element.querySelector(".menu-toggle");

        // Cacher le bouton hamburger SPÉCIFIQUE au "below"
        if (config.mobileMenuType === "below") {
            toggleButton.style.display = "none"; // Masque le toggle
        }

        // Ne PAS activer l'overlay pour "below"
        if (config.mobileMenuType !== "below") {
            overlay.style.display = "block";
            setTimeout(() => {
                overlay.style.opacity = "1";
            }, 10);
        }

        // Mettre à jour l'état visuel
        element.classList.add("menu-open");

        // Afficher l'overlay si nécessaire
        if (config.mobileMenuType !== "below") {
            overlay.style.display = "block";
            setTimeout(() => {
                overlay.style.opacity = "1";
            }, 10);
        }

        // Animer selon le type de menu
        mobileMenu.style.display = "block";
        setTimeout(() => {
            mobileMenu.style.opacity = "1";

            if (config.mobileMenuType === "sidebar") {
                mobileMenu.style.transform = "translateX(0)";
            }
        }, 10);

        // Gérer le verrouillage du scroll pour les menus fullpage et sidebar
        if (
            config.mobileMenuType === "fullpage" ||
            config.mobileMenuType === "sidebar"
        ) {
            this.toggleBodyScroll(false);
        }

        if (config.mobileMenuType === "below") {
            element.querySelector(".menu-toggle").style.display = "none";
        }

        // Mettre à jour l'état stocké
        this.headers.set(headerId, {
            ...header,
            isOpen: true,
        });
    }

    closeMobileMenu(headerId) {
        const header = this.headers.get(headerId);
        if (!header || !header.isOpen) return;

        const { element, config } = header;
        const mobileMenu = element.querySelector(".mobile-menu");
        const overlay = element.querySelector(".menu-overlay");
        const toggleButton = element.querySelector(".menu-toggle");

        if (config.mobileMenuType === "below") {
            toggleButton.style.display = "block"; // Rétablit le toggle
        }

        // Mettre à jour l'état visuel
        element.classList.remove("menu-open");

        // Masquer l'overlay
        if (overlay) {
            overlay.style.opacity = "0";
            setTimeout(() => {
                overlay.style.display = "none";
            }, 300);
        }

        // Animer la fermeture selon le type de menu
        mobileMenu.style.opacity = "0";

        if (config.mobileMenuType === "sidebar") {
            const transform =
                config.sidebarPosition === "left"
                    ? "translateX(-100%)"
                    : "translateX(100%)";
            mobileMenu.style.transform = transform;
        }

        setTimeout(() => {
            mobileMenu.style.display = "none";
        }, 300);

        // Réactiver le scroll si nécessaire
        if (
            config.mobileMenuType === "fullpage" ||
            config.mobileMenuType === "sidebar"
        ) {
            this.toggleBodyScroll(true);
        }

        if (config.mobileMenuType === "below") {
            element.querySelector(".menu-toggle").style.display = "block";
        }

        // Mettre à jour l'état stocké
        this.headers.set(headerId, {
            ...header,
            isOpen: false,
        });
    }

    applyLayoutConfig(headerId) {
        const header = this.headers.get(headerId);
        if (!header) return;

        const { element, config } = header;

        // Appliquer les classes positionnelles
        element.className = element.className.replace(
            /logo-(left|center|right)|nav-(left|center|right)|action-(left|center|right)|mobile-(sidebar|below|fullpage)|sidebar-(left|right)/g,
            ""
        );

        element.classList.add(
            `logo-${config.logoPosition}`,
            `nav-${config.navPosition}`,
            `action-${config.actionPosition}`,
            `mobile-${config.mobileMenuType}`
        );

        if (config.mobileMenuType === "sidebar") {
            element.classList.add(`sidebar-${config.sidebarPosition}`);
        }

        // Ajuster la mise en page en fonction de la taille d'écran
        this.adjustLayoutForBreakpoint(headerId);
    }

    getCurrentBreakpoint() {
        const width = window.innerWidth;
        if (width < 576) return "xs";
        if (width < 768) return "sm";
        if (width < 992) return "md";
        if (width < 1200) return "lg";
        return "xl";
    }

    handleResize() {
        const newBreakpoint = this.getCurrentBreakpoint();

        // Si le breakpoint a changé
        if (newBreakpoint !== this.currentBreakpoint) {
            this.currentBreakpoint = newBreakpoint;

            // Mettre à jour tous les headers
            this.headers.forEach((header, id) => {
                this.adjustLayoutForBreakpoint(id);

                // Fermer les menus mobiles si on passe en mode desktop
                if (["lg", "xl"].includes(newBreakpoint) && header.isOpen) {
                    this.closeMobileMenu(id);
                }
            });
        }
    }

    adjustLayoutForBreakpoint(headerId) {
        const header = this.headers.get(headerId);
        if (!header) return;

        const { element } = header;
        const isMobile = ["xs", "sm", "md"].includes(this.currentBreakpoint);

        // Basculer entre la vue mobile et desktop
        element.classList.toggle("mobile-view", isMobile);
        element.classList.toggle("desktop-view", !isMobile);

        // S'assurer que les menus mobiles sont bien positionnés initialement
        if (isMobile) {
            const mobileMenu = element.querySelector(".mobile-menu");
            if (mobileMenu) {
                if (header.config.mobileMenuType === "sidebar") {
                    const transform =
                        header.config.sidebarPosition === "left"
                            ? "translateX(-100%)"
                            : "translateX(100%)";
                    mobileMenu.style.transform = transform;
                }
                mobileMenu.style.opacity = "0";
                mobileMenu.style.display = "none";
            }
        }
    }

    toggleBodyScroll(enable) {
        if (enable && this.bodyScrollLock) {
            // Réactiver le scroll
            document.body.style.overflow = "";
            document.body.style.paddingRight = "";
            this.bodyScrollLock = false;
        } else if (!enable && !this.bodyScrollLock) {
            // Désactiver le scroll
            const scrollbarWidth =
                window.innerWidth - document.documentElement.clientWidth;
            document.body.style.overflow = "hidden";
            document.body.style.paddingRight = `${scrollbarWidth}px`;
            this.bodyScrollLock = true;
        }
    }

    // Méthode pour mettre à jour la configuration d'un header
    updateHeaderConfig(headerId, newConfig) {
        const header = this.headers.get(headerId);
        if (!header) return;

        // Mettre à jour la configuration
        this.headers.set(headerId, {
            ...header,
            config: { ...header.config, ...newConfig },
        });

        // Appliquer les modifications
        this.applyLayoutConfig(headerId);
    }

    // Méthode pour initialiser les dropdowns dans le menu mobile après sa création
    initializeMobileMenuDropdowns(mobileMenu) {
        // Trouver tous les dropdowns dans le menu mobile
        const dropdowns = mobileMenu.querySelectorAll(".dropdown");
        dropdowns.forEach((dropdown) => {
            // Laisser le DropdownManager initialiser ces dropdowns
            this.dropdownManager.initializeDropdown(dropdown);
        });

        // Faire de même pour les dropdowns fullwidth
        const fullwidthDropdowns = mobileMenu.querySelectorAll(
            ".dropdown-fullwidth"
        );
        fullwidthDropdowns.forEach((dropdown) => {
            this.dropdownManager.initializeFullwidthDropdown(dropdown);
        });
    }
}
