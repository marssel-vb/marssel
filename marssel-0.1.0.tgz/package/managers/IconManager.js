export class IconManager {
    constructor(marssel) {
        this.marssel = marssel;
        this.icons = {};
        this.sizes = {
            small: "16px",
            medium: "24px",
            large: "32px",
            xlarge: "48px",
        };
        this.isLoaded = false;
    }

    async init() {
        try {
            const response = await fetch("/js/icons-manifest.json");
            this.icons = await response.json();
            this.isLoaded = true; // Marquer comme chargé
            //console.log("Loaded icons:", Object.keys(this.icons));
        } catch (error) {
            console.warn(
                "Manifeste d'icônes non trouvé, utilisation des icônes par défaut",
                error
            );
            this.icons = {};
            this.isLoaded = true; // Marquer comme chargé même en cas d'erreur
        }
    }

    getIconContent(className) {
        if (!this.isLoaded) {
            console.warn("Icons manifest not loaded yet.");
            return null; // Ou retourner une icône par défaut
        }

        // Expression régulière pour capturer le nom de l'icône avec les types solid/duotone
        const match = className.match(
            /^icon-\\\[([a-z0-9-]+(?:-solid|-duotone)?)\\\]$/i
        );

        if (!match) {
            console.warn("No icon match for className:", className);
            return null;
        }

        const fullIconName = match[1]; // Ex: 'star-solid', 'brush-2-duotone', 'chevron-left'

        // Déterminer le type d'icône à partir du suffixe
        let iconType = "outline"; // Par défaut si aucun suffixe
        let iconName = fullIconName;

        if (fullIconName.endsWith("-solid")) {
            iconType = "solid";
            iconName = fullIconName.replace(/-solid$/, "");
        } else if (fullIconName.endsWith("-duotone")) {
            iconType = "duotone";
            iconName = fullIconName.replace(/-duotone$/, "");
        }

        // Construire la clé pour la recherche dans icons
        const iconKey =
            iconType === "outline" ? iconName : `${iconName}-${iconType}`;

        const icon = this.icons[iconKey];

        if (!icon) {
            console.warn(`Icon not found: ${iconKey}`);
            return null;
        }

        return icon;
    }

    createIconStyles(selector, className) {
        const icon = this.getIconContent(className);

        if (!icon) return new Set();

        const declarations = new Set();

        // Base container styles
        declarations.add("position: relative");
        declarations.add("display: inline-block");
        declarations.add("vertical-align: middle");
        declarations.add(`width: var(--icon-size)`);
        declarations.add(`height: var(--icon-size)`);

        // Parse color from className
        const colorMatch = className.match(/c-\[(.*?)\]/);
        const color = colorMatch ? `#${colorMatch[1]}` : "currentColor";

        const encodedSvg = encodeURIComponent(icon.svg);

        declarations.add(`background-color: ${color}`);
        declarations.add(
            `-webkit-mask-image: url("data:image/svg+xml,${encodedSvg}")`
        );
        declarations.add(`mask-image: url("data:image/svg+xml,${encodedSvg}")`);
        declarations.add("-webkit-mask-repeat: no-repeat");
        declarations.add("mask-repeat: no-repeat");
        declarations.add("-webkit-mask-position: center");
        declarations.add("mask-position: center");
        declarations.add("-webkit-mask-size: contain");
        declarations.add("mask-size: contain");

        return declarations;
    }
}
