export class ModalManager {
    constructor(marssel) {
        this.marssel = marssel;
        this.overlay = null;
    }

    init() {
        this.overlay = document.getElementById("modal-overlay");

        // Exposition des méthodes globales
        window.openModal = (id) => this.openModal(id);
        window.closeModal = (id) => this.closeModal(id);

        // Gestion du clic sur l'overlay
        this.overlay.addEventListener("click", () => {
            document.querySelectorAll('[id^="modal-"]').forEach((modal) => {
                modal.style.display = "none";
            });
            this.overlay.style.display = "none";
            document.body.style.overflow = "";
        });
    }

    openModal(id) {
        if (id !== "modal-fullscreen") {
            this.overlay.style.display = "block";
        }

        const modal = document.getElementById(id);
        if (modal) {
            modal.style.display = "block";
            document.body.style.overflow = "hidden";
        }
    }

    closeModal(id) {
        const modal = document.getElementById(id);
        if (modal) {
            this.overlay.style.display = "none";
            document.body.style.overflow = "";
            modal.style.display = "none";
        }

        // Vérifier s'il reste des modales ouvertes
        const activeModals = document.querySelectorAll(
            '[id^="modal-"][style*="display: block"]'
        );
        if (activeModals.length === 0) {
            this.overlay.style.display = "none";
            document.body.style.overflow = "";
        }
    }
}
