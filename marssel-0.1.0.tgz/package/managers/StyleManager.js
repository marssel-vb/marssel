import { cleanValue, buildMediaQuery } from "../utils/helpers.js";
import { parseGutterValue } from "../utils/parsed.js";

export class StyleManager {
    constructor(marssel, config = {}) {
        console.log("Constructeur StyleManager avec config:", config);
        this.marssel = marssel;
        this.fontFaces = new Set();
        this.selectorDeclarations = new Map();
        this.compiledRules = new Map();

        // Utiliser config au lieu de options
        this.lazyload =
            config && typeof config.lazyload === "boolean"
                ? config.lazyload
                : false;

        console.log("StyleManager.lazyload configuré à:", this.lazyload);
        this.lazyObserver = null;
        this.lazyElements = new Map();
    }

    // Méthode pour initialiser l'IntersectionObserver pour le lazyloading
    initLazyObserver() {
        if (!this.lazyload) return;

        this.lazyObserver = new IntersectionObserver(
            (entries) => {
                entries.forEach((entry) => {
                    if (entry.isIntersecting) {
                        const element = entry.target;
                        const classes = this.lazyElements.get(element);

                        if (classes) {
                            classes.forEach((className) => {
                                if (className.includes("+")) {
                                    this.marssel.domManager.processCombinedClass(
                                        className
                                    );
                                } else {
                                    this.marssel.domManager.processClassName(
                                        className
                                    );
                                }
                            });

                            // Génération réalisée, on peut supprimer et arrêter d'observer
                            this.lazyElements.delete(element);
                            this.lazyObserver.unobserve(element);
                        }

                        this.debounceStyleUpdate();
                    }
                });
            },
            {
                rootMargin: "800px", // Marge pour précharger les styles avant que l'élément soit visible
                threshold: 0.01, // Déclencher dès qu'une petite partie est visible
            }
        );
    }

    ensureStyleElement() {
        if (!document.getElementById("marssel-styles")) {
            const style = document.createElement("style");
            style.id = "marssel-styles";
            document.head.appendChild(style);
        }
    }

    initializeStyleSheet() {
        this.ensureStyleElement();

        if (this.lazyload) {
            this.initLazyObserver();
        }

        requestAnimationFrame(() => {
            this.marssel.domManager.processAllElements();
            this.updateStyles();
        });
    }

    buildSelector(parsed) {
        let selector = parsed.component
            ? `.${parsed.component}`
            : `.${parsed.finalClassName}`;

        if (parsed.pseudoModifiers) {
            const modifiers = parsed.pseudoModifiers.split("-");
            let pseudoElement = null;
            const pseudoClasses = [];

            modifiers.forEach((mod) => {
                if (mod === "before" || mod === "after") {
                    pseudoElement = mod;
                } else {
                    pseudoClasses.push(mod);
                }
            });

            // Appliquer d'abord les pseudo-classes
            pseudoClasses.forEach((pc) => {
                selector += `:${pc}`;
            });

            // Puis le pseudo-élément
            if (pseudoElement) {
                selector += `::${pseudoElement}`;
            }
        }

        return selector;
    }

    wrapWithMediaQuery(selector, declaration, breakpoints) {
        if (!breakpoints?.length) return `${selector} { ${declaration} }`;

        const mediaQuery = buildMediaQuery(breakpoints);
        return `@media ${mediaQuery} { ${selector} { ${declaration} } }`;
    }

    // === Méthodes de base ===
    addFontFace(cssText) {
        this.fontFaces.add(cssText);
    }

    updateStyles() {
        const styleElement = document.getElementById("marssel-styles");
        if (!styleElement) return;

        let css = [];

        // Ajouter les @font-face en premier
        if (this.fontFaces.size > 0) {
            css.push(Array.from(this.fontFaces).join("\n"));
        }

        // Traiter d'abord les règles sans media queries
        this.selectorDeclarations.forEach((declarations, selector) => {
            if (!selector.startsWith("@media")) {
                css.push(
                    `${selector} { ${Array.from(declarations).join("; ")} }`
                );
            }
        });

        // Traiter ensuite les media queries
        this.selectorDeclarations.forEach((mediaQuerySelectors, mediaQuery) => {
            if (mediaQuery.startsWith("@media")) {
                let mediaQueryRules = [];
                mediaQuerySelectors.forEach((declarations, selector) => {
                    mediaQueryRules.push(
                        `${selector} { ${Array.from(declarations).join("; ")} }`
                    );
                });
                css.push(`${mediaQuery} { ${mediaQueryRules.join(" ")} }`);
            }
        });

        styleElement.textContent = css.join("\n");
    }

    addDefaultStyles() {
        if (!this.marssel.iconManager.isLoaded) {
            console.warn("Icons not loaded yet, skipping default styles.");
            return;
        }

        // Règles box-sizing pour tous les éléments
        const boxSizingDeclarations = new Set();
        boxSizingDeclarations.add("box-sizing: border-box");
        this.addDeclarationsWithMediaQuery([], "*", boxSizingDeclarations);
        this.addDeclarationsWithMediaQuery(
            [],
            "*::before",
            boxSizingDeclarations
        );
        this.addDeclarationsWithMediaQuery(
            [],
            "*::after",
            boxSizingDeclarations
        );

        // Variable :root pour la taille des icônes
        const rootDeclarations = new Set();
        const iconSize = this.marssel.iconManager.sizes.medium;
        rootDeclarations.add(`--icon-size: ${iconSize}`);
        this.addDeclarationsWithMediaQuery([], ":root", rootDeclarations);

        this.updateStyles();
    }

    addStyleRule(parsed) {
        const rule = this.generateRule(parsed);

        if (rule) {
            this.styleSheet.add(rule);

            // Déclencher la mise à jour des styles si nécessaire
            this.debounceStyleUpdate();
        }
    }

    // Optimisation du debouncing des mises à jour de style
    debounceStyleUpdate = (() => {
        let timeout;
        const DEBOUNCE_DELAY = 16; // ~1 frame à 60fps

        return () => {
            if (timeout) {
                clearTimeout(timeout);
            }

            timeout = setTimeout(() => {
                this.updateStyles();
                timeout = null;
            }, DEBOUNCE_DELAY);
        };
    })();

    generateRule(parsed) {
        const cacheKey = JSON.stringify(parsed);
        if (this.compiledRules.has(cacheKey)) {
            return this.compiledRules.get(cacheKey);
        }

        let rule = "";
        const { property, value } = parsed;
        const selector = this.buildSelector(parsed);
        let declarations = new Set();

        // Gestion des icônes
        if (property === "icon-size") {
            const size = this.marssel.iconManager.sizes[value] || value;
            declarations.add(`--icon-size: ${size}`);
        } else if (parsed.property === "icon") {
            declarations = this.marssel.iconManager.createIconStyles(
                selector,
                parsed.finalClassName
            );
        } else if (parsed.property === "font") {
            const match = value.match(/^(.*?)(?:\[(\d*)(?:_(.*?))?\])?$/);
            if (match) {
                const fontFamily = match[1].replace(/_/g, " ");
                const fontWeight =
                    match[2] && match[2] !== "" ? match[2] : "400";
                const fontStyle = match[3] === "italic" ? "italic" : "normal";

                this.marssel.fontManager.handleFont(fontFamily, fontWeight);

                declarations.add(`font-family: '${fontFamily}', sans-serif`);
                declarations.add(`font-weight: ${fontWeight}`);
                declarations.add(`font-style: ${fontStyle}`);
            }
        }

        // Gestion spéciale pour les propriétés transform
        else if (property === "transform") {
            declarations.add(`transform: ${cleanValue(value)}`);
        }

        // Handle gutters
        else if (["gutter", "gutter-x", "gutter-y"].includes(property)) {
            const direction = property.split("-")[1] || "all";
            const gutterValue = parseGutterValue(value);
            if (!gutterValue) return "";

            // Parent gutter declarations
            if (direction === "x" || direction === "all") {
                declarations.add(`margin-left: -${gutterValue}`);
                declarations.add(`margin-right: -${gutterValue}`);
            }
            if (direction === "y" || direction === "all") {
                declarations.add(`margin-top: -${gutterValue}`);
                declarations.add(`margin-bottom: -${gutterValue}`);
            }

            // Child selector declarations
            const childSelector = `${selector} > [class*="col-"]`;
            const childDeclarations = new Set();
            if (direction === "x" || direction === "all") {
                childDeclarations.add(`padding-left: ${gutterValue}`);
                childDeclarations.add(`padding-right: ${gutterValue}`);
            }
            if (direction === "y" || direction === "all") {
                childDeclarations.add(`padding-top: ${gutterValue}`);
                childDeclarations.add(`padding-bottom: ${gutterValue}`);
            }
            childDeclarations.add("box-sizing: border-box");

            // Handle media queries for both parent and child
            this.addDeclarationsWithMediaQuery(
                parsed.breakpoints,
                selector,
                declarations
            );
            this.addDeclarationsWithMediaQuery(
                parsed.breakpoints,
                childSelector,
                childDeclarations
            );
        }

        // Handle column system
        else if (property === "col") {
            switch (value) {
                case "container":
                    declarations.add("width: 100%");
                    declarations.add("margin: 0 auto");
                    declarations.add("padding: 0 12px");

                    if (parsed.breakpoints.length > 0) {
                        parsed.breakpoints.forEach((bp) => {
                            const maxWidth =
                                this.marssel.constructor.containerMaxWidths[bp];
                            if (maxWidth) {
                                declarations.add(`max-width: ${maxWidth}`);
                            }
                        });
                    } else {
                        // Add all container max-widths as separate media queries
                        Object.entries(
                            this.marssel.constructor.containerMaxWidths
                        ).forEach(([bp, width]) => {
                            const mediaQuery = `(min-width: ${this.marssel.constructor.breakpoints[bp]})`;
                            const mediaQueryKey = `@media ${mediaQuery}`;
                            const mediaSelector = selector;

                            if (!this.selectorDeclarations.has(mediaQueryKey)) {
                                this.selectorDeclarations.set(
                                    mediaQueryKey,
                                    new Map()
                                );
                            }

                            const mediaSelectors =
                                this.selectorDeclarations.get(mediaQueryKey);
                            if (!mediaSelectors.has(mediaSelector)) {
                                mediaSelectors.set(mediaSelector, new Set());
                            }

                            mediaSelectors
                                .get(mediaSelector)
                                .add(`max-width: ${width}`);
                        });
                    }
                    break;

                case "row":
                    declarations.add("display: flex");
                    declarations.add("flex-wrap: wrap");
                    declarations.add("margin-right: -12px");
                    declarations.add("margin-left: -12px");

                    // Child row elements
                    const childSelector = `${selector} > *`;
                    const childDeclarations = new Set();
                    childDeclarations.add("padding-right: 12px");
                    childDeclarations.add("padding-left: 12px");

                    this.addDeclarationsWithMediaQuery(
                        parsed.breakpoints,
                        selector,
                        declarations
                    );
                    this.addDeclarationsWithMediaQuery(
                        parsed.breakpoints,
                        childSelector,
                        childDeclarations
                    );
                    break;

                default:
                    if (value === "auto") {
                        declarations.add("flex: 0 0 auto");
                        declarations.add("width: auto");
                        declarations.add("max-width: 100%");
                    } else {
                        const numericValue = parseInt(cleanValue(value));
                        const percentage =
                            ((numericValue / 12) * 100).toFixed(4) + "%";

                        if (parsed.breakpoints.length > 0) {
                            // Responsive column
                            declarations.add(`flex: 0 0 ${percentage}`);
                            declarations.add(`max-width: ${percentage}`);
                        } else {
                            // Base column (full width)
                            declarations.add("flex: 0 0 100%");
                            declarations.add("max-width: 100%");
                            declarations.add("width: 100%");
                        }
                    }
                    break;
            }
        } else if (property === "content") {
            // Traitement spécial pour la propriété content
            declarations.add(
                `content: "${cleanValue(value.replace(/_/g, " "))}"`
            );
        } else if (property === "bg-linear") {
            // Traitement du dégradé linéaire
            const cleanedValue = cleanValue(value);
            declarations.add(`background: linear-gradient(${cleanedValue})`);
        } else if (property === "bg-radial") {
            // Traitement du dégradé radial
            const cleanedValue = cleanValue(value);
            declarations.add(`background: radial-gradient(${cleanedValue})`);
        }
        // 3. Gestion des autres propriétés
        else {
            // 3a. Propriétés personnalisées (non définies dans Marssel.properties)
            if (!this.marssel.constructor.properties[property]) {
                const formattedProperty = property.replace(/_/g, "-");
                let cssValue = cleanValue(value);
                declarations.add(`${formattedProperty}: ${cssValue}`);
            } else {
                let cssValue = cleanValue(value);
                let cssProperty = this.marssel.constructor.properties[property];

                if (
                    ["bg", "c"].includes(property) ||
                    property.startsWith("bg-") ||
                    property.startsWith("c-")
                ) {
                    cssValue = this.marssel.domManager.processColor(cssValue);
                }

                if (Array.isArray(cssProperty)) {
                    cssProperty.forEach((prop) => {
                        declarations.add(`${prop}: ${cssValue}`);
                    });
                } else {
                    declarations.add(`${cssProperty}: ${cssValue}`);
                }
            }
        }

        // Add declarations to selectorDeclarations
        if (declarations.size > 0) {
            this.addDeclarationsWithMediaQuery(
                parsed.breakpoints,
                selector,
                declarations
            );
        }

        this.compiledRules.set(cacheKey, rule);
        return rule;
    }

    addDeclarationsWithMediaQuery(breakpoints, selector, declarations) {
        if (breakpoints.length > 0) {
            const mediaQuery = buildMediaQuery(breakpoints);
            const mediaQueryKey = `@media ${mediaQuery}`;

            if (!this.selectorDeclarations.has(mediaQueryKey)) {
                this.selectorDeclarations.set(mediaQueryKey, new Map());
            }

            const mediaSelectors = this.selectorDeclarations.get(mediaQueryKey);
            if (!mediaSelectors.has(selector)) {
                mediaSelectors.set(selector, new Set());
            }

            declarations.forEach((decl) => {
                mediaSelectors.get(selector).add(decl);
            });
        } else {
            if (!this.selectorDeclarations.has(selector)) {
                this.selectorDeclarations.set(selector, new Set());
            }

            declarations.forEach((decl) => {
                this.selectorDeclarations.get(selector).add(decl);
            });
        }
    }

    // Dans StyleManager.js
    setLazyload(enabled) {
        // Si on active le lazyload
        if (enabled && !this.lazyload) {
            this.lazyload = true;
            this.initLazyObserver();

            // Réinitialiser le traitement des éléments
            document.querySelectorAll("*").forEach((element) => {
                this.marssel.domManager.processElement(element);
            });
        }
        // Si on désactive le lazyload
        else if (!enabled && this.lazyload) {
            this.lazyload = false;

            // Traiter tous les éléments en attente
            this.lazyElements.forEach((classes, element) => {
                classes.forEach((className) => {
                    if (className.includes("+")) {
                        this.marssel.domManager.processCombinedClass(className);
                    } else {
                        this.marssel.domManager.processClassName(className);
                    }
                });
            });

            // Vider la liste et désactiver l'observer
            this.lazyElements.clear();
            if (this.lazyObserver) {
                this.lazyObserver.disconnect();
            }

            this.updateStyles();
        }
    }
}
